create schema prm_poc;


DROP TABLE IF EXISTS prm_poc.book;

CREATE TABLE prm_poc.book (
`title` varchar(50) NOT NULL,
  `isbn` varchar(12)  DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
 `publisheddate` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`title`)
)


insert into prm_poc.book values ('Title1','24453389011',  'mytest1' , '2019-08-14');
insert into prm_poc.book values ('Title2','24453389012',   'mytest2' , '2019-08-14');
insert into prm_poc.book values ('Title3','24453389013',   'mytest3' , '2019-08-14');


DROP TABLE IF EXISTS prm_poc.review;

CREATE TABLE prm_poc.review (
    `reviewid` INT(10) NOT NULL AUTO_INCREMENT ,
  `reviewername` varchar(50) DEFAULT NULL,
  `content` varchar(250) DEFAULT NULL,
  `rating` varchar(10) DEFAULT NULL,
  `publisheddate` varchar(10) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`reviewid`),
   FOREIGN KEY (title) REFERENCES prm_poc.book(title)

)


insert into prm_poc.review values (1,'avc','aww',  '2' ,'2019-08-14', 'Title2');
insert into prm_poc.review values (2,'avcasdsad','aww',  '4' ,'2019-08-14', 'Title1');
insert into prm_poc.review values (3,'avc121','aww',  '3' ,'2019-08-14', 'Title1');
