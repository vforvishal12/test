package com.prmpoc.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "review")
public class Review {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "reviewid")
	String reviewid;
	
	@Column(name = "reviewername")
	String reviewername;

	@Column(name = "content")
	String content;

	@Column(name = "rating")
	String rating;

	@Column(name = "publisheddate")
	String publisheddate;

	
	public Review(String reviewername, String content, String rating, String publisheddate) {
		super();
		this.reviewername = reviewername;
		this.content = content;
		this.rating = rating;
		this.publisheddate = publisheddate;
	}

	public Review() {

	}
	

	public String getReviewid() {
		return reviewid;
	}

	public void setReviewid(String reviewid) {
		this.reviewid = reviewid;
	}

	public String getReviewername() {
		return reviewername;
	}

	public void setReviewername(String reviewername) {
		this.reviewername = reviewername;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getPublisheddate() {
		return publisheddate;
	}

	public void setPublisheddate(String publisheddate) {
		this.publisheddate = publisheddate;
	}

}
