package com.prmpoc.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prmpoc.demo.entity.Book;
import com.prmpoc.demo.service.BookService;

@RestController
@RequestMapping("/prmapi")
public class TestController {

	@GetMapping("/test")
	public String test() {
		return "Hello World PRM-POC!  " + System.currentTimeMillis();
	}

	private BookService bookService;

	@Autowired
	public TestController(BookService theBookService) {
		bookService = theBookService;
	}

	@GetMapping("/books")
	public List<Book> findAll() {
		return bookService.findAll();
	}

	@GetMapping("/books/{title}")
	public Book getBookByTitle(@PathVariable("title") String theTitle) {
		Book theBooks = bookService.findByTitle(theTitle);

		if (theBooks == null) {
			throw new RuntimeException("The Title id not found - " + theTitle);
		}

		return theBooks;
	}

	@PostMapping("/books")
	public Book addBook(@RequestBody Book theBook) {
		//theBook.setTitle("1 ");
		bookService.save(theBook);
		return theBook;
	}

	@PutMapping("/books")
	public Book updateBook(@RequestBody Book theBook) {
		bookService.save(theBook);
		return theBook;

	}

	@DeleteMapping("/books/{title}")
	public String deleteBook(@PathVariable String title) {
		Book theBook = bookService.findByTitle(title);
		if (theBook == null) {
			throw new RuntimeException("Title not found - " + title);
		}
		bookService.deleteByTitle(title);
		return "Deleted Title" + title;

	}

}
