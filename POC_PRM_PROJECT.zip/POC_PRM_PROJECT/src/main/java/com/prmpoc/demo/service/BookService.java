package com.prmpoc.demo.service;

import java.util.List;

import com.prmpoc.demo.entity.Book;

public interface BookService {

	public List<Book> findAll();

	public Book findByTitle(String theTitle);

	public void save(Book theBook);

	public void deleteByTitle(String theTitle);

}
