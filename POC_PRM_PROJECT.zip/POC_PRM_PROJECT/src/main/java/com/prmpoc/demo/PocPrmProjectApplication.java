package com.prmpoc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocPrmProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocPrmProjectApplication.class, args);
	}

}
