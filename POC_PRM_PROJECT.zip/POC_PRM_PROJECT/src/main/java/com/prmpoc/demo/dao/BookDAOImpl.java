package com.prmpoc.demo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.prmpoc.demo.entity.Book;

@Repository
public class BookDAOImpl implements BookDAO {

	private EntityManager entityManager;

	@Autowired
	public BookDAOImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}

	@Override
	public List<Book> findAll() {

		Session currentSession = entityManager.unwrap(Session.class);
		Query<Book> theQuery = currentSession.createQuery("from Book", Book.class);
		List<Book> bookList = theQuery.getResultList();
		return bookList;
	}

	@Override
	public Book findByTitle(String theTitle) {
		Session currentSession = entityManager.unwrap(Session.class);
		Book theBook = currentSession.get(Book.class, theTitle);

		return theBook;
	}

	@Override
	public void save(Book theBook) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		currentSession.saveOrUpdate(theBook);

	}

	@Override
	public void deleteByTitle(String theTitle) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("delete from Book where id=:title");
		theQuery.setParameter("title", theTitle);
		theQuery.executeUpdate();

	}

}
