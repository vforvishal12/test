package com.prmpoc.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prmpoc.demo.dao.BookDAO;
import com.prmpoc.demo.entity.Book;

@Service
public class BookServiceImpl implements BookService {

	private BookDAO bookDAO;
	
	@Autowired
	public BookServiceImpl(@Qualifier("bookDAOImpl") BookDAO theBookDAO ) {
		bookDAO= theBookDAO;
	}
	
	@Override
	@Transactional
	public List<Book> findAll() {
		return bookDAO.findAll();
	}

	@Override
	@Transactional
	public Book findByTitle(String theTitle) {
		return bookDAO.findByTitle(theTitle);
	}

	@Override
	@Transactional
	public void save(Book theBook) {
		bookDAO.save(theBook);
	}

	@Override
	@Transactional
	public void deleteByTitle(String theTitle) {
		bookDAO.deleteByTitle(theTitle);
	}

}
