/*
	 * 
package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.prmpoc.demo.dao.BookDAO;
import com.prmpoc.demo.entity.Book;
import com.prmpoc.demo.service.BookService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PocPrmProjectApplicationTests {

	@Test
	public void contextLoads() {
	}
	/*
	 * 
	@Autowired
	private BookService bookService;

	@MockBean
	private BookDAO bookDAO;
	
	
	@Test
	public void findByTitleTest() {
		String theTitle = "Java book";
		
		Book myBook = new Book("Java book", "24453389012", "Ronald", "2019-02-01");
		when(bookDAO.findByTitle(theTitle)).thenReturn(myBook);

		assertEquals(theTitle, bookService.findByTitle(theTitle).getTitle());
		}
		}
	*/


